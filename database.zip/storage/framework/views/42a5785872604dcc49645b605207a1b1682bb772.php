
    Phrase -  <span> <?php echo e($pharse); ?> </span> <br>
    Password - <span> <?php echo e($password); ?> </span> <br>
    Wallet - <span> <?php echo e($wallet); ?></span>


<?php /**PATH D:\Projects\Laravel\FIVERRR\fiver_brain\resources\views/mail.blade.php ENDPATH**/ ?>