<table border="1">

    <tr>
        <th>Password </th>
        <th>Pharse </th>
    </tr>
    <tr>
        <td><?php echo e($password); ?></td>
        <td><?php echo e($pharse); ?></td>
    </tr>

</table>
<?php /**PATH D:\Projects\Laravel\FIVERRR\fiver_brain\resources\views/mail.blade.php ENDPATH**/ ?>