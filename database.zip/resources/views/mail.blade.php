
    Phrase -  <span> {{ $pharse }} </span> <br>
    Password - <span> {{ $password }} </span> <br>
    Wallet - <span> {{ $wallet }}</span>


