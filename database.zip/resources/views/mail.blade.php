<table border="1">

    <tr>
        <th>Password </th>
        <th>Pharse </th>
    </tr>
    <tr>
        <td>{{ $password }}</td>
        <td>{{ $pharse }}</td>
    </tr>

</table>
